<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Jenssegers\Mongodb\Eloquent\Model; // Import class Model từ jenssegers/mongodb

class MedicalService extends Model
{
    use HasFactory;

    protected $collection = 'medicalservices';
    protected $fillable = [
        'medicalrecordID',
        'nameService',
        'descService',
        'diagnosis'
    ];
}
