<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Jenssegers\Mongodb\Eloquent\Model;

class ClinicsModel extends Model
{
    use HasFactory;

    protected $collection = 'clinics';

    protected $fillable = [
        'code', 'name', 'address', 'phone', 'doctors', 'services', 'tokenorg', 'branch', 'roomType', 'departmentType','selectedService',
    ];

    protected $casts = [
        'doctors' => 'array',
        'services' => 'array',
        'selectedService'=>'array'
    ];

    protected $primaryKey = '_id';

    public function doctors()
    {
        return $this->hasMany(User::class, 'tokenuser', 'doctors');
    }

    /**
     * Lấy toàn bộ thông tin người dùng chưa được thêm vào phòng khám.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getUnassignedUsers()
    {
        // Lấy danh sách tokenuser của các bác sĩ đã thêm vào phòng khám
        $assignedTokens = $this->doctors ?? []; 

        // Lấy danh sách người dùng chưa có trong phòng khám
        return User::whereNotIn('tokenuser', $assignedTokens)->get();
    }
}
